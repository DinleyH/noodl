module.exports = {
  None: require('./transitions/none-transition'),
  Push: require('./transitions/push-transition'),
  Popup: require('./transitions/popup-transition')
};
